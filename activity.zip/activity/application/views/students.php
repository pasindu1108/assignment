<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
        
        </div>
    </div>
</div>

<h4>Students</h4>
<table class="table table-bordered">

  <thead>
      <tr>
          <th>Student ID</th>
          <th>Student Name</th>
      </tr>
  </thead>

  <tbody>
   <?php foreach ($data as $student) { ?>      
      <tr>
          <td><?php echo $student->student_id; ?></td>
          <td><?php echo $student->student_name; ?></td> 
         
      </tr>
      <?php } ?>
  </tbody>

</table>


<hr>


<h4>Teachers</h4>
<table class="table table-bordered">

  <thead>
      <tr>
          <th>Teacher ID</th>
          <th>Teacher Name</th>
      </tr>
  </thead>

  <tbody>
   <?php foreach ($datat as $teacher) { ?>      
      <tr>
          <td><?php echo $teacher->teacher_id; ?></td>
          <td><?php echo $teacher->teacher_name; ?></td> 
         
      </tr>
      <?php } ?>
  </tbody>

</table>
 

<hr>


<h4>Subjects</h4>
<table class="table table-bordered">

  <thead>
      <tr>
          <th>Subject ID</th>
          <th>Subject Name</th>
      </tr>
  </thead>

  <tbody>
   <?php foreach ($datas as $subject) { ?>      
      <tr>
          <td><?php echo $subject->id; ?></td>
          <td><?php echo $subject->subject_name; ?></td> 
         
      </tr>
      <?php } ?>
  </tbody>

</table>


<hr>


<h4>Student's Subjects</h4>
<table class="table table-bordered table-sm" >
    
    <thead>
      <tr>
		<th>Student ID</th>
        <th>Student Name</th>
        <th>Subject Name</th>
        <th>Teacher Name</th>
      </tr>
    </thead>
   
    <tbody id="table">
      
    </tbody>
    
</table>





