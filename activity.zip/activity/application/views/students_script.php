<script>
	$.ajax({
		url: "<?php echo base_url("Students/show");?>",
		type: "POST",
		cache: false,
		success: function(data){
			$('#table').html(data); 
		}
	});
</script>