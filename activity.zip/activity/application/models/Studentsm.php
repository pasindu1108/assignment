<?php


class Studentsm extends CI_Model{


    public function getstudents(){
       
        $query = $this->db->get("students");
        return $query->result();
    }

    public function getteachers(){
       
        $query = $this->db->get("teachers");
        return $query->result();
    }

    public function getsubjects(){
       
        $query = $this->db->get("subjects");
        return $query->result();
    }

    public function studentsubjects(){
       

        $this->db->select('students.student_name,students.student_id,subject_name, teacher_name');    
        $this->db->from('students');
        $this->db->join('enrollments', 'students.student_id = enrollments.student_id');
        $this->db->join('subjects', 'enrollments.subject_id = subjects.id');
        $this->db->join('teachers', 'enrollments.subject_id = teachers.subject_id');
        $this->db->order_by('students.student_id','asc'); 
        $query = $this->db->get();

        
        return $query->result();
    }
}
?>