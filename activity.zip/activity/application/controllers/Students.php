<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Students extends CI_Controller {


   public $Students;


   /**
    * Get All Data from this method.
    *
    * @return Response
   */
   public function __construct() {
      parent::__construct(); 


      $this->load->library('form_validation');
      $this->load->library('session');
      $this->load->model('Studentsm');
      

      $this->Studentsm = new Studentsm;
   }


   /**
    * Display Data this method.
    *
    * @return Response
   */
   public function index()
   {
       $data['data'] = $this->Studentsm->getstudents();
       $data['datat'] = $this->Studentsm->getteachers();
       $data['datas'] = $this->Studentsm->getsubjects();
       $data['all'] = $this->Studentsm->studentsubjects();
       $data['dataa'] = $this->Studentsm->studentsubjects();

      

       $this->load->view('theme/header');  
       $this->load->view('students',$data);
       $this->load->view('students_script');
       $this->load->view('theme/footer');
   }

   
   public function show(){

    $data = $this->Studentsm->studentsubjects();
   
    $i=1;
				foreach($data as $row)
				{
					  echo "<tr>";
					  echo "<td>".$row->student_id."</td>";
					  echo "<td>".$row->student_name."</td>";
					  echo "<td>".$row->subject_name."</td>";
                 echo "<td>".$row->teacher_name."</td>";
					  echo "</tr>";
				
				}

   }



}